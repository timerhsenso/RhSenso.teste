using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace RhSenso.Shared.SEG.Sistemas;

/// <summary>
/// DTO para listagem de sistemas - usado em grids e consultas
/// </summary>
public sealed record SistemaListDto(
    [property: JsonPropertyName("codigo")] string Codigo,
    [property: JsonPropertyName("descricao")] string Descricao
);

/// <summary>
/// DTO para criação de novos sistemas
/// </summary>
public sealed class SistemaCreateDto
{
    /// <summary>
    /// Código do sistema (obrigatório, até 10 caracteres)
    /// </summary>
    [JsonPropertyName("codigo")]
    [Required(ErrorMessage = "Código do sistema é obrigatório")]
    [StringLength(10, ErrorMessage = "Código deve ter no máximo 10 caracteres")]
    public string Codigo { get; set; } = string.Empty;

    /// <summary>
    /// Descrição do sistema (obrigatório, até 100 caracteres)
    /// </summary>
    [JsonPropertyName("descricao")]
    [Required(ErrorMessage = "Descrição do sistema é obrigatória")]
    [StringLength(100, ErrorMessage = "Descrição deve ter no máximo 100 caracteres")]
    public string Descricao { get; set; } = string.Empty;
}

/// <summary>
/// DTO para atualização de sistemas existentes
/// </summary>
public sealed class SistemaUpdateDto
{
    /// <summary>
    /// Descrição do sistema (obrigatório, até 100 caracteres)
    /// </summary>
    [JsonPropertyName("descricao")]
    [Required(ErrorMessage = "Descrição do sistema é obrigatória")]
    [StringLength(100, ErrorMessage = "Descrição deve ter no máximo 100 caracteres")]
    public string Descricao { get; set; } = string.Empty;
}

/// <summary>
/// DTO para formulários de sistema - usado em telas de cadastro
/// </summary>
public sealed class SistemaFormDto
{
    /// <summary>
    /// Código do sistema
    /// </summary>
    public string Codigo { get; set; } = string.Empty;

    /// <summary>
    /// Descrição do sistema
    /// </summary>
    public string Descricao { get; set; } = string.Empty;
}

